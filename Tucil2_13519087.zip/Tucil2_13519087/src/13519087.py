# Hizkia Raditya Pratama Roosadi/ 13519087
# Tugas Kecil Strategi Algoritma
# Membuat program topological sort untuk menentukan mata kuliah
# menggunakan algoritma decrease and conquer

#a simple graph class
class graph:
    #we use the built in python dict to make the graph adt
    def __init__(self,gdict=None):
        if gdict is None:
            gdict = {}
        self.gdict = gdict
            
    # Add vertex to a graph
    def addVertex(self, vrtx):
       if vrtx not in self.gdict:
            self.gdict[vrtx] = []
    # returns list of vertices
    def getVertices(self):
        return list(self.gdict.keys())
    def isEmpty(self):
        if(self.gdict=={}):
            return True
        else:
            return False

#adding prereq into a dict
def addPrereq(dict_obj, key, value):
    # Check if key exist in dict or not
    if key in dict_obj:
        # Key exist in dict.
        # Check if type of value of key is list or not
        if not isinstance(dict_obj[key], list):
            # If type is not list then make it list
            dict_obj[key] = [dict_obj[key]]
        # Append the value in list
        dict_obj[key].append(value)
    else:
        # As key is not in dict,
        # so, add key-value pair
        dict_obj[key] = value

#find key with no values
def findZeroIndegree(gdict):
    for x in gdict:
        if(len(gdict[x])==0):
           return x;
    
#delete all corresponding values from key pair value
def delCorrespondingValue(gdict,val):
    for x in gdict:
        if (val in gdict[x]):
            gdict[x].remove(val)
  
#create an empty graph and an array to contain the input
g=graph({})
lline=[]

#read input from txt file, put input inside of lline array
with open("test.txt", "r") as filestream:
    for line in filestream:
        line=line.replace(".\n","")
        line=line.replace(".","")
        line=line.replace("\n","")
        currentline=line.split(",")
        lline.append(currentline)


#add the elmt[0] of each elmt in the lline array as vertex
for elmt in lline:
    for i in range(0,len(elmt)):
        g.addVertex(elmt[0])
#add the other elements as prereq
for elmt in lline:
    for i in range(0,len(elmt)-1):
        addPrereq(g.gdict,elmt[0],elmt[i+1])

#create array for the solution and i for counting semester
curSolution=[]
i=1

while (not g.isEmpty()):
    x=findZeroIndegree(g.gdict) #find the first solution
    
    if (x is None): #if the first solution is None, then the graph input is not acyclic
        print ("The input is not in the form of acyclic graph")
        break
    
    print("semester "+str(i)+": ",end='')
    while (x is not None):#in case there are more than 1 solution i.e. more matkul per semester without prereq
        curSolution.append(x) #appends to an array
        del g.gdict[x] #delete the corresponding key
        x=findZeroIndegree(g.gdict) #find a new key
    for y in range (0,len(curSolution)): #print function for all the matkul inside the array
        delCorrespondingValue(g.gdict,curSolution[y]) #delete all corresponding value from the dict
        if (y==0):
            print(curSolution[y],end='')
        else:
            print(", "+curSolution[y],end='')
            
    curSolution.clear()#we clear the array for each iteration
        
    i+=1
    print("\n")


