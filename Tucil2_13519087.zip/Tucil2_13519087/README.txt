Halo, ini adala program penyusun mata kuliah dengan algoritma decrease and conquer.
program ini dibuat untuk penyelesaian tugas kecil mata kuliah Strategi Algoritma IF2211.
program ini mengimplementasikan topological sort dan graph untuk menentukan
mata kuliah mana yang harus diambil per semester.

Requirements:
1. Install Python IDLE untuk perangkat anda
2. Python IDLE ada pada link berikut: https://www.python.org/downloads/
3. alternatif: ikuti link ini untuk instalasi pada linux: https://phoenixnap.com/kb/how-to-install-python-3-ubuntu

Cara menggunakan program:
1. Buka folder src
2. Buka file test
3. Anda bisa menuliskan soal sendiri atau mengcopy-paste soal dari folder test
4. pastikan format soal sebagai berikut

<kode_kuliah_1>,<kode kuliah prasyarat - 1>, <kode kuliah prasyarat - 2>, <kode kuliah
prasyarat - 3>.
<kode_kuliah_2>,<kode kuliah prasyarat - 1>, <kode kuliah prasyarat - 2>.
<kode_kuliah_3>,<kode kuliah prasyarat - 1>, <kode kuliah prasyarat - 2>, <kode kuliah
prasyarat - 3>, <kode kuliah prasyarat - 4>.
<kode_kuliah_4>.
.
.

5. Buka file 13519087.py lewat IDLE
6. Klik Run dan jalankan program
7. Tunggu sampai hasil keluar.
8. Alternatif: program juga dapat dijalankan pada command line
9. gunakan command: python 13519087.py

Penulis: Hizkia Raditya Pratama Roosadi/13519087
Kontak: 087741451005/ id line: hizkiacanggih  (prefered using LINE)

Terima kasih sudah mau mencobaa